import * as pdfjsLib from "pdfjs-dist/legacy/build/pdf.mjs";
// Initialize the worker in Next.js environment
import "pdfjs-dist/legacy/build/pdf.worker.mjs";

export interface RawParsedPage {
  pageNumber: number;
  rawText: string;
}

export interface RawPDFParseResult {
  totalPages: number;
  pages: RawParsedPage[];
}

interface PdfTextItem {
  str: string;
  dir: string;
  width: number;
  height: number;
  transform: number[]; // [scaleX, skewX, skewY, scaleY, tx, ty]
  fontName: string;
}

function parsePageItemsToLines(items: unknown[]): string {
  const textItems = items.filter(
    (item): item is PdfTextItem => {
      if (!item || typeof item !== "object") return false;
      const obj = item as Record<string, unknown>;
      return typeof obj.str === "string" && Array.isArray(obj.transform);
    }
  );

  if (textItems.length === 0) return "";

  // Group items by Y coordinate (transform[5])
  // Sort Y descending (top-to-bottom)
  const sortedItems = [...textItems].sort((a, b) => {
    const yDiff = b.transform[5] - a.transform[5];
    if (Math.abs(yDiff) > 5) {
      return yDiff;
    }
    return a.transform[4] - b.transform[4];
  });

  const lines: { y: number; items: PdfTextItem[] }[] = [];
  for (const item of sortedItems) {
    const y = item.transform[5];
    
    let foundLine = lines.find(l => Math.abs(l.y - y) <= 5);
    if (!foundLine) {
      foundLine = { y, items: [] };
      lines.push(foundLine);
    }
    foundLine.items.push(item);
  }

  // Sort lines by Y descending (top-to-bottom)
  lines.sort((a, b) => b.y - a.y);

  const formattedLines: string[] = [];
  for (const line of lines) {
    // Sort items horizontally ascending (left-to-right)
    line.items.sort((a, b) => a.transform[4] - b.transform[4]);

    let lineStr = "";
    for (let idx = 0; idx < line.items.length; idx++) {
      const item = line.items[idx];
      const text = item.str || "";
      if (idx === 0) {
        lineStr = text;
      } else {
        const prevItem = line.items[idx - 1];
        const gap = item.transform[4] - (prevItem.transform[4] + prevItem.width);
        
        // Gap threshold for table columns (e.g. 12 points)
        if (gap > 12) {
          lineStr += " | " + text;
        } else {
          if (gap > 1) {
            lineStr += " " + text;
          } else {
            lineStr += text;
          }
        }
      }
    }
    formattedLines.push(lineStr.trim());
  }

  return formattedLines.join("\n");
}

/**
 * Extracts raw page-by-page text from a PDF ArrayBuffer using pdfjs-dist.
 * Performs validation checks and throws human-readable errors for passwords,
 * corruption, and empty files.
 */
export async function parsePDF(arrayBuffer: ArrayBuffer): Promise<RawPDFParseResult> {
  if (!arrayBuffer || arrayBuffer.byteLength === 0) {
    throw new Error("The PDF file is empty or missing data.");
  }

  const data = new Uint8Array(arrayBuffer);
  let pdfDoc;

  try {
    const loadingTask = pdfjsLib.getDocument({
      data,
      useSystemFonts: true,
      disableFontFace: true,
    });
    pdfDoc = await loadingTask.promise;
  } catch (err) {
    console.error("[PDF Parser] Document load rejection:", err);

    const pdfError = err as { name?: string; message?: string };
    const errName = pdfError?.name;
    if (errName === "PasswordException") {
      throw new Error("PDF is password-protected. Please remove the password and try again.");
    }
    if (errName === "InvalidPDFException" || errName === "FormatError" || pdfError?.message?.includes("corrupted")) {
      throw new Error("The PDF file appears to be corrupted or invalid.");
    }
    if (errName === "MissingPDFException") {
      throw new Error("The PDF file is empty or missing.");
    }
    throw new Error(`Failed to load PDF document: ${pdfError?.message || "Unknown parsing issue"}`);
  }

  const numPages = pdfDoc.numPages;
  if (numPages === 0) {
    throw new Error("The PDF contains no pages.");
  }

  const pages: RawParsedPage[] = [];

  for (let pageNum = 1; pageNum <= numPages; pageNum++) {
    try {
      const page = await pdfDoc.getPage(pageNum);
      const textContent = await page.getTextContent();
      
      const pageText = parsePageItemsToLines(textContent.items);
        
      pages.push({
        pageNumber: pageNum,
        rawText: pageText,
      });
    } catch (err) {
      console.error(`[PDF Parser] Error parsing page ${pageNum}:`, err);
      const pageError = err as { message?: string };
      throw new Error(`Failed to parse PDF page ${pageNum}: ${pageError?.message || "Unknown error"}`);
    }
  }

  // Validate that the document contains at least some readable text characters
  const overallLength = pages.reduce((acc, p) => acc + p.rawText.trim().length, 0);
  if (overallLength === 0) {
    throw new Error("The PDF contains no readable text.");
  }

  return {
    totalPages: numPages,
    pages,
  };
}
