import { RetrievedChunk } from "./types";
import { getTopicFromText } from "../chunkingEngine/chunker";

/**
 * Detects the primary topic from user query, supporting synonyms, plurals, abbreviations, and DSA terms.
 */
export function detectQueryTopic(query: string): string | null {
  const lower = query.toLowerCase();
  
  const mapping: Record<string, string[]> = {
    "recursion": ["recursion", "recursive", "fibonacci", "factorial"],
    "tree": ["tree", "trees", "bst", "binary search tree", "binary tree", "root", "leaf", "cousins"],
    "graph": ["graph", "graphs", "dfs", "bfs", "dijkstra", "kruskal", "prim", "vertex", "edge", "connected components"],
    "linked list": ["linked list", "linked lists", "ll"],
    "string": ["string", "strings"],
    "array": ["array", "arrays", "two sum", "reverse array", "palindrome", "subarray", "traversal"],
    "dynamic programming": ["dynamic programming", "dp"],
    "stack": ["stack", "stacks", "push", "pop", "peek"],
    "queue": ["queue", "queues", "enqueue", "dequeue"],
    "sorting": ["sorting", "sort", "bubble sort", "merge sort", "quick sort"],
    "searching": ["searching", "search", "binary search", "linear search"]
  };
  
  for (const [topic, keywords] of Object.entries(mapping)) {
    for (const kw of keywords) {
      const regex = new RegExp(`\\b${kw}s?\\b`, "i");
      if (regex.test(lower)) {
        return topic;
      }
    }
  }
  
  return null;
}

/**
 * Scores how relevant a chunk is to the query's requested topic.
 */
function scoreTopicRelevance(queryTopic: string | null, text: string): number {
  if (!queryTopic) return 0;
  
  let score = 0;
  
  // Detected heading matches query topic
  const lines = text.split("\n");
  const heading = lines.find(l => l.startsWith("#") || l.toUpperCase() === l);
  if (heading && heading.toLowerCase().includes(queryTopic)) {
    score += 0.4;
  }
  
  // Topic label match
  const chunkTopic = getTopicFromText(text);
  if (chunkTopic === queryTopic) {
    score += 0.5;
  }
  
  return score;
}

/**
 * Checks if the next chunk is a logical continuation of the previous chunk.
 */
function isContinuation(prev: RetrievedChunk, next: RetrievedChunk): boolean {
  // 1. Must be on same page or adjacent page
  const pageDiff = Math.abs(next.pageStart - prev.pageEnd);
  if (pageDiff > 1) return false;
  
  // 2. Check for new topic or heading
  const nextTrimmed = next.fullText.trim();
  
  // If next starts with a heading or subheading, it is a new section
  if (nextTrimmed.startsWith("#") || /^\s*\d+\s+[A-Z]/.test(nextTrimmed)) {
    return false;
  }
  
  // If next has an explicit Topic label
  if (/\b(topic|section|unit|module)\s*:/i.test(nextTrimmed)) {
    return false;
  }
  
  // If next changes the active topic
  const prevTopic = getTopicFromText(prev.fullText);
  const nextTopic = getTopicFromText(next.fullText);
  if (prevTopic && nextTopic && prevTopic !== nextTopic) {
    return false;
  }
  
  // 3. Continues numbering, bullet lists, or explanation
  const nextLines = nextTrimmed.split("\n").map(l => l.trim()).filter(Boolean);
  if (nextLines.length === 0) return true;
  
  const firstLine = nextLines[0];
  
  // Check if first line starts with a list bullet or numbered list
  const isNumbered = /^\d+[\.\)]/.test(firstLine);
  const isBullet = /^[\-\*\u2022]/.test(firstLine);
  
  if (isNumbered || isBullet) {
    return true;
  }
  
  // Continues explanation (starts with lowercase or standard sentence flow)
  if (/^[a-z]/.test(firstLine)) {
    return true;
  }
  
  return true;
}

/**
 * Intelligent Retrieval Context Processor.
 * Filters, scores, merges, and deduplicates retrieved chunks before prompt generation.
 */
export function processRetrievedContext(
  query: string,
  chunks: RetrievedChunk[]
): RetrievedChunk[] {
  if (chunks.length === 0) return [];

  const requestedTopic = detectQueryTopic(query);

  // Step 1 & 2: Score and Discard Unrelated Chunks
  const scored = chunks.map(chunk => {
    let score = chunk.similarityScore;

    // Keyword overlap
    const cleanQuery = query.toLowerCase().replace(/[^a-z0-9\s]/g, "");
    const queryWords = cleanQuery.split(/\s+/).filter(w => w.length > 2);
    const chunkText = chunk.fullText.toLowerCase();

    let overlap = 0;
    for (const word of queryWords) {
      if (chunkText.includes(word)) {
        overlap++;
      }
    }
    score += overlap * 0.02;

    // Topic overlap & Topic score boosting
    if (requestedTopic) {
      score += scoreTopicRelevance(requestedTopic, chunk.fullText);
    } else {
      const queryTopic = getTopicFromText(query);
      const chunkTopic = getTopicFromText(chunk.fullText);
      if (queryTopic && chunkTopic && queryTopic === chunkTopic) {
        score += 0.3;
      }
    }

    // Heading relevance
    const lines = chunk.fullText.split("\n");
    const heading = lines.find(l => l.startsWith("#") || l.toUpperCase() === l);
    if (heading) {
      let headingOverlap = 0;
      for (const word of queryWords) {
        if (heading.toLowerCase().includes(word)) {
          headingOverlap++;
        }
      }
      score += headingOverlap * 0.05;
    }

    // Step 3: Boost structured chunks
    // Priority: Question block > Topic block > Heading > Paragraph
    const hasQuestion = /\b(q\d+|question\s*\d+|q\s*:)/i.test(chunk.fullText) || /^\s*\d+[\.\)]\s+/m.test(chunk.fullText);
    const hasTopic = chunk.fullText.toLowerCase().includes("topic:");
    
    if (hasQuestion) {
      score += 0.3; // Question block
    } else if (hasTopic) {
      score += 0.2; // Topic block
    } else if (heading) {
      score += 0.1; // Heading
    }

    return { chunk, score };
  });

  // Topic filter / Discard chunks of other topics
  let filtered = scored;
  if (requestedTopic) {
    filtered = scored.filter(item => {
      const chunkTopic = getTopicFromText(item.chunk.fullText);
      if (chunkTopic && chunkTopic !== requestedTopic) {
        return false;
      }
      return true;
    });
  }

  // Sort by score descending
  filtered.sort((a, b) => b.score - a.score);

  // Map back to RetrievedChunk array
  let processedChunks = filtered.map(item => ({ ...item.chunk }));

  // Special Handling - Content level filtering (definitions vs questions vs examples)
  processedChunks = processedChunks.map(c => {
    c.fullText = filterRetrievedChunkContent(query, c.fullText);
    c.characterCount = c.fullText.length;
    return c;
  }).filter(c => c.fullText.length > 0);

  // Step 4: Merge neighboring chunks & Continuation detection
  const merged: RetrievedChunk[] = [];
  for (const chunk of processedChunks) {
    if (merged.length > 0) {
      const prev = merged[merged.length - 1];
      const prevTopic = getTopicFromText(prev.fullText);
      const currTopic = getTopicFromText(chunk.fullText);

      // Check if continuation conditions are met
      const topicMatches = prevTopic === currTopic && prevTopic !== null;
      if (topicMatches && isContinuation(prev, chunk)) {
        prev.fullText += "\n\n" + chunk.fullText;
        prev.pageEnd = Math.max(prev.pageEnd, chunk.pageEnd);
        prev.characterCount = prev.fullText.length;
        prev.similarityScore = Math.max(prev.similarityScore, chunk.similarityScore);
        continue;
      }
    }
    merged.push(chunk);
  }

  // Step 5: Remove duplicate questions, keeping the richer one
  const deduped = removeQuestionsDuplicates(merged);

  return deduped;
}

function filterRetrievedChunkContent(query: string, text: string): string {
  const lowerQuery = query.toLowerCase();

  const isDefinitionsQuery = /\b(definition|definitions|define|explain|explanation)\b/.test(lowerQuery);
  const isQuestionsQuery = /\b(question|questions|practice questions|practice question|problems)\b/.test(lowerQuery);
  const isExamplesQuery = /\b(example|examples)\b/.test(lowerQuery);

  const lines = text.split("\n");
  const filteredLines: string[] = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.length === 0) {
      filteredLines.push(line);
      continue;
    }

    const isQ = /^\s*(Q\d+|Question\s*\d+|Q\s*:|\[Q\d+\])/i.test(trimmed) || /^\s*\d+[\.\)]\s+/.test(trimmed);
    const isBullet = /^\s*([\-\*\u2022]|\+\s)\s+/.test(trimmed);

    if (isDefinitionsQuery) {
      if (isQ) continue;
      if (isBullet && /\b(implement|write|find|count|print|design|check|solve)\b/i.test(trimmed)) {
        continue;
      }
      filteredLines.push(line);
    } else if (isQuestionsQuery) {
      const isHeader = /^\s*#/.test(trimmed) || (trimmed.length < 60 && trimmed === trimmed.toUpperCase()) || trimmed.toLowerCase().startsWith("topic:");
      if (isHeader || isQ || isBullet) {
        filteredLines.push(line);
      }
    } else if (isExamplesQuery) {
      if (trimmed.toLowerCase().startsWith("example") || trimmed.toLowerCase().includes("example:")) {
        filteredLines.push(line);
      }
    } else {
      filteredLines.push(line);
    }
  }

  return filteredLines.join("\n").replace(/\n{3,}/g, "\n\n").trim();
}

function removeQuestionsDuplicates(chunks: RetrievedChunk[]): RetrievedChunk[] {
  const result: RetrievedChunk[] = [];

  for (const chunk of chunks) {
    let isDuplicate = false;
    const currentQuestions = extractQuestionLines(chunk.fullText);

    if (currentQuestions.length > 0) {
      for (let idx = 0; idx < result.length; idx++) {
        const existing = result[idx];
        const existingQuestions = extractQuestionLines(existing.fullText);

        const intersection = currentQuestions.filter(q => {
          const cleanQ = q.toLowerCase().replace(/[^a-z0-9]/g, "");
          return existingQuestions.some(eq => {
            const cleanEq = eq.toLowerCase().replace(/[^a-z0-9]/g, "");
            return cleanEq.includes(cleanQ) || cleanQ.includes(cleanEq);
          });
        });

        if (intersection.length > 0 && intersection.length >= currentQuestions.length * 0.5) {
          isDuplicate = true;
          if (chunk.fullText.length > existing.fullText.length) {
            result[idx] = chunk;
          }
          break;
        }
      }
    }

    if (!isDuplicate) {
      result.push(chunk);
    }
  }

  return result;
}

function extractQuestionLines(text: string): string[] {
  return text.split("\n")
    .map(line => line.trim())
    .filter(line => /^\s*(Q\d+|Question\s*\d+|Q\s*:|\[Q\d+\])/i.test(line) || /^\s*\d+[\.\)]\s+/.test(line));
}
